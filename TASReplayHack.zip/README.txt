Run MAKESMB.BAT to generate rom

Uses inputs.fm3 as input file
Note that the fm3 must be saved as a binary format (default)
Also there must not be any comments in the header
Only supports 1 player

Requires python to be installed