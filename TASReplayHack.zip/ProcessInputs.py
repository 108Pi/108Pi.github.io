import csv
from itertools import groupby

def extract_and_write_data(input_file, output_file):
    with open(input_file, "rb") as infile:
        # Read until the 18th line
        for _ in range(18):
            line = infile.readline().decode("utf-8")

        # Extract length value
        if "length " in line:
            length = int(line.split("length ")[1].strip())
        else:
            raise ValueError("Expected 'length ' not found on the 18th line.")

        # Skip the next byte
        infile.read(1)

        # Read the specified number of bytes (length * 2)
        data = infile.read(length * 2)

        # Convert bytes to decimal values
        decimal_values = [byte for byte in data]

    # Write decimal values to CSV
    with open(output_file, "w", newline="") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(decimal_values)

def process_file(input_filename, output_filename):
    def reverse_bits(n):
        return int(f"{n:08b}"[::-1], 2)

    with open(input_filename, "r") as infile:
        numbers = infile.read().strip().split(",")

    # Remove the opposite every other number
    filtered_numbers = [reverse_bits(int(num)) for num in numbers[1::2]]

    # Count consecutive occurrences
    compressed_numbers = []
    for num, group in groupby(filtered_numbers):
        count = len(list(group))
        while count > 255:
            compressed_numbers.extend([255, num])
            count -= 255
        compressed_numbers.extend([count, num])

    # Subtract 5 from the first number
    if compressed_numbers:
        compressed_numbers[0] -= 5

    # Convert numbers to a formatted string with ".byte" every 32 values
    lines = ["TASINPUTS:"]
    for i in range(0, len(compressed_numbers), 32):
        line = ".byte " + ", ".join(map(str, compressed_numbers[i:i+32]))
        lines.append(line)

    # Write to the output file
    with open(output_filename, "w") as outfile:
        outfile.write("\n".join(lines))

# Example usage

extract_and_write_data("inputs.fm3", "inputsraw.txt")
process_file("inputsraw.txt", "tasinputs.asm")